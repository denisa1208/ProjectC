#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "imageprocessing.h"
#include "bmp.h"
#define NM 10
#define  NMA 101
int main() {
    // TODO(.): Task 7
    int v_N[NM];
    int v_M[NM];
    int v_Nf[NM];
    float ***v_f = calloc(NMA, sizeof(int**));
    int ****v = calloc(NMA, sizeof(int***));
    if (v == NULL) {
        exit(-1);
    }
    int ok = 1;
    int nr = 0;
    int N = 0;
    int M = 0;
    int nr_f = 0;
    char x[3];
    while (ok) {
        fgets(x, 3, stdin);
        if (x[0] == 'e') {
            ok = 0;
        } else if (x[0] == 'l') {
            scanf("%d%d", &N, &M);
            char path[NMA];
            scanf("%s", path);
            v_M[nr] = M;
            v_N[nr] = N;
            v[nr] = calloc(N, sizeof(int**));
            if (v[nr] == NULL) {
               exit(-1);
            }
            for (int i = 0; i < N; i++) {
                v[nr][i] = calloc(M, sizeof(int*));
                if (v[nr][i] == NULL) {
                    exit(-1);
                }
                for (int j = 0; j < M; j++) {
                    v[nr][i][j] = calloc(3, sizeof(int));
                    if (v[nr][i][j] == NULL) {
                        exit(-1);
                    }
                }
            }
            read_from_bmp(v[nr], v_N[nr], v_M[nr], path);
            nr++;
        } else if (x[0] == 's') {
            int index = 0;
            scanf("%d", &index);
            char path_s[NMA];
            scanf("%s", path_s);
            write_to_bmp(v[index], v_N[index], v_M[index], path_s);
        } else if (x[0] == 'a' && x[1] == 'h') {
            int index = 0;
            scanf("%d", &index);
            v[index] = flip_horizontal(v[index], v_N[index], v_M[index]);
        } else if (x[0] == 'a' && x[1] == 'r') {
            int index = 0;
            scanf("%d", &index);
            v[index] = rotate_left(v[index], v_N[index], v_M[index]);
            int aux = 0;
            aux = v_N[index];
            v_N[index] = v_M[index];
            v_M[index] = aux;
        } else if (x[0] =='a' && x[1] =='c') {
            int index = 0, x = 0, y = 0, w = 0, h = 0;
            scanf("%d%d%d%d%d", &index, &x, &y, &w, &h);
            v[index] = crop(v[index], v_N[index], v_M[index], x, y, h, w);
            v_N[index] = h;
            v_M[index] = w;

        } else if (x[0] == 'a' && x[1] == 'e') {
            int index = 0, rows = 0, cols = 0, R = 0, G = 0, B = 0;
            scanf("%d%d%d%d%d%d", &index, &rows, &cols, &R, &G, &B);
            int n = v_N[index] + 2 * rows;
            int m = v_M[index] + 2 * cols;
            v[index] = extend(v[index], v_N[index], v_M[index], rows, cols, R, G, B);
            v_N[index] = n;
            v_M[index] = m;
        } else if (x[0]== 'a' && x[1] == 'p') {
            int index1 = 0, index2 = 0, x = 0, y = 0;
            scanf("%d%d%d%d", &index1, &index2, &x, &y);
            v[index1] = paste(v[index1], v_N[index1], v_M[index1], v[index2], v_N[index2], v_M[index2], x, y);
        } else if (x[0] == 'c' && x[1] == 'f') {
            int f_size = 0;
            scanf("%d", &f_size);
            v_f[nr_f] = calloc(f_size, sizeof(int*));
            if (v_f[nr_f] == NULL) {
                exit(-1);
            }
            for (int i = 0; i < f_size; i++) {
                v_f[nr_f][i] = calloc(f_size, sizeof(float));
                if (v_f[nr_f][i] == NULL) {
                    exit(-1);
                }
            }
            for (int i = 0; i < f_size; i++) {
                for (int j = 0; j < f_size; j++) {
                    float x = 0;
                    scanf("%f", &x);
                    v_f[nr_f][i][j] = x;
                }
            }
            v_Nf[nr_f] = f_size;
            nr_f++;
        } else if (x[0] == 'a' && x[1] == 'f') {
            int index = 0, index_f = 0;
            scanf("%d%d", &index, &index_f);
            v[index] = apply_filter(v[index], v_N[index], v_M[index], v_f[index_f], v_Nf[index_f]);
        } else if (x[0] == 'd' && x[1] == 'f') {
            int index_f = 0;
            scanf("%d", &index_f);
            for (int i = 0; i < v_Nf[index_f]; i++) {
                free(v_f[index_f][i]);
            }
            free(v_f[index_f]);
            for (int i = index_f; i < nr_f - 1; i++) {
                v_Nf[i] = v_Nf[i+1];
                v_f[i] = v_f[i+1];
            }
            nr_f--;
        } else if (x[0] == 'd' && x[1] == 'i') {
            int index = 0;
            scanf("%d", &index);
            for (int i = 0; i < v_N[index]; i++) {
                for (int j = 0; j < v_M[index]; j++) {
                    free(v[index][i][j]);
                }
                free(v[index][i]);
            }
            free(v[index]);


            for (int i = index; i < nr - 1; i++) {
                v_N[i] = v_N[i+1];
                v_M[i] = v_M[i+1];
                v[i] = v[i+1];
            }
            nr--;
        }
    }
    for (int i = 0; i < nr; i++) {
        for (int j = 0; j < v_N[i]; j++) {
            for (int k = 0; k < v_M[i]; k++) {
                free(v[i][j][k]);
            }
            free(v[i][j]);
        }
        free(v[i]);
    }
    free(v);
    for (int i = 0; i < nr_f; i++) {
        for (int j = 0; j < v_Nf[i]; j++) {
            free(v_f[i][j]);
        }
        free(v_f[i]);
    }
    free(v_f);
    return 0;
}
