#include <stdio.h>
#include <stdlib.h>
#include "imageprocessing.h"
#define nrm 255
// TODO(.): Task 1
int ***flip_horizontal(int ***image, int N, int M) {
    int ***cp = calloc(N, sizeof(int**));
    if (cp == NULL) {
        exit(-1);
    }
    for (int i = 0; i < N; i++) {
        cp[i] = calloc(M, sizeof(int*));
        if (cp[i] == NULL) {
            exit(-1);
        }
        for (int j = 0; j < M; j++) {
            cp[i][j] = calloc(3, sizeof(int));
            if (cp[i][j] == NULL) exit(-1);
            cp[i][j][0] = image[i][M - 1 - j][0];
            cp[i][j][1] = image[i][M - 1 - j][1];
            cp[i][j][2] = image[i][M - 1 - j][2];
        }
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            image[i][j][0] = cp[i][j][0];
            image[i][j][1] = cp[i][j][1];
            image[i][j][2] = cp[i][j][2];
        }
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            free(cp[i][j]);
        }
        free(cp[i]);
    }
    free(cp);
    return image;
}

// TODO(.): Task 2
int ***rotate_left(int ***image, int N, int M) {
    int ***cp = calloc(M, sizeof(int**));
    if (cp == NULL) exit(-1);
    for (int i = 0; i < M; i++) {
        cp[i] = calloc(N, sizeof(int*));
        if (cp[i] == NULL) exit(-1);
        for (int j = 0; j < N; j++) {
            cp[i][j] = calloc(3, sizeof(int));
            if (cp[i][j] == NULL) {
                exit(-1);
            }
        }
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            cp[j][i][0] = image[i][M-1-j][0];
            cp[j][i][1] = image[i][M-1-j][1];
            cp[j][i][2] = image[i][M-1-j][2];
        }
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            free(image[i][j]);
        }
        free(image[i]);
    }
    free(image);
    return cp;
}

// TODO(.): Task 3
int ***crop(int ***image, int N, int M, int x, int y, int h, int w) {
    int ***cp = calloc(h, sizeof(int**));
    if (cp == NULL) {
        exit(-1);
    }
    for (int i = 0; i < h; i++) {
        cp[i] = calloc(w, sizeof(int*));
        if (cp[i] == NULL) {
            exit(-1);
        }
        for (int j = 0; j < w; j++) {
            cp[i][j] = calloc(3, sizeof(int));
            if (cp[i][j] == NULL) {
                exit(-1);
            }
        }
    }
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            cp[i][j][0] = image[i+y][j+x][0];
            cp[i][j][1] = image[i+y][j+x][1];
            cp[i][j][2] = image[i+y][j+x][2];
        }
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            free(image[i][j]);
        }
        free(image[i]);
    }
    free(image);
    return cp;
}

// TODO(.): Task 4
int ***extend(int ***image, int N, int M, int rows, int cols, int new_R, int new_G, int new_B) {
    int n = N + 2 * rows;
    int m = M + 2 * cols;
    int ***cp = calloc(n, sizeof(int**));
    if (cp == NULL) {
        exit(-1);
    }
    for (int i = 0; i < n; i++) {
        cp[i] = calloc(m, sizeof(int*));
        if (cp[i] == NULL) {
            exit(-1);
        }
        for (int j = 0; j < m; j ++) {
            cp[i][j] = calloc(3, sizeof(int));
            if (cp[i][j] == NULL) {
                exit(-1);
            }
        }
    }

    int ci = 0;
    int cj = 0;

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < m; k++) {
                if (i == 0) {
                    cp[j][k][i] = new_R;
                } else if (i == 1) {
                    cp[j][k][i] = new_G;
                } else if (i == 2) {
                    cp[j][k][i] = new_B;
                }
            }
        }
    }
    for (int i = rows; i < rows + N; i++) {
            cj = 0;
            for (int j = cols; j < cols + M; j++) {
                cp[i][j][0] = image[ci][cj][0];
                cp[i][j][1] = image[ci][cj][1];
                cp[i][j][2] = image[ci][cj][2];
                cj++;
            }
            ci++;
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            free(image[i][j]);
        }
        free(image[i]);
    }
    free(image);
    return cp;
}

// TODO(.): Task 5
int ***paste(int ***image_dst, int N_dst, int M_dst, int ***image_src, int N_src, int M_src, int x, int y) {
    int ci = 0;
    int cj = 0;
    for (int k = 0; k < 3; k++) {
        ci = 0;
        cj = 0;
        for (int i = y; i < N_dst && ci < N_src; i++, ci++) {
            cj = 0;
            for (int j = x; j < M_dst && cj < M_src; j++, cj++) {
                image_dst[i][j][k] = image_src[ci][cj][k];
            }
        }
    }
    return image_dst;
}

// TODO(.): Task 6
int ***apply_filter(int ***image, int N, int M, float **filter, int filter_size) {
    int n = N + filter_size - 1;
    int m = M + filter_size - 1;
    int ***cp = calloc(n, sizeof(int**));
    if (cp == NULL) {
        exit(-1);
    }
    for (int i = 0; i < n; i++) {
        cp[i] = calloc(m, sizeof(int*));
        if (cp[i] == NULL) {
            exit(-1);
        }
        for (int j = 0; j < m; j++) {
            cp[i][j] = calloc(3, sizeof(int));
            if (cp[i][j] == NULL) {
                exit(-1);
            }
        }
    }


  //  int **mat=aloc(mat, N, M);
    int ***mat = calloc(N, sizeof(int**));
    if (mat == NULL) {
        exit(-1);
    }
    for (int i = 0; i < N; i++) {
        mat[i] = calloc(M, sizeof(int*));
        if (mat == NULL) {
            exit(-1);
        }
        for (int j = 0; j < M; j++) {
            mat[i][j] = calloc(3, sizeof(int));
            if (mat[i][j] == NULL) {
                exit(-1);
            }
        }
    }
    for (int k = 0; k < 3; k++) {
        for (int i = filter_size/2; i < N + filter_size/2; i++) {
            for (int j = filter_size/2; j < M + filter_size/2; j++) {
                cp[i][j][k] = image[i-filter_size/2][j-filter_size/2][k];
                //  printf("%d ", cp[i][j]);
            }
        }
    }
    float s = 0;
    int ci = 0;
    int cj = 0;
    int c = 0, b = 0;
    for (int k = 0; k < 3; k++) {
        s = 0;
        for (int i = filter_size/2; i < N+filter_size/2; i++) {
        for (int j = filter_size/2; j < M+filter_size/2; j++) {
            s = 0;
            for (c = i-filter_size/2, ci = 0; c <= i+filter_size/2 && ci < filter_size; c++, ci++) {
                for (b = j-filter_size/2, cj = 0; b <= j+filter_size/2 && cj < filter_size; b++, cj++) {
                    s = s + (float)cp[c][b][k]*filter[ci][cj];
                }
            }
            if (s > nrm) {
                mat[i-filter_size/2][j-filter_size/2][k] = nrm;
            } else if (s < 0) {
                mat[i-filter_size/2][j-filter_size/2][k] = 0;
            } else {
                mat[i-filter_size/2][j-filter_size/2][k] = (int)s;
            }
            }
        }
    }
    // nu am dat return la imagine, am dat la alta matrice
    for (int k = 0; k < 3; k++) {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                image[i][j][k] = mat[i][j][k];
            }
        }
    }
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            free(mat[i][j]);
        }
        free(mat[i]);
    }
    free(mat);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            free(cp[i][j]);
        }
        free(cp[i]);
    }
    free(cp);

    return image;
}
